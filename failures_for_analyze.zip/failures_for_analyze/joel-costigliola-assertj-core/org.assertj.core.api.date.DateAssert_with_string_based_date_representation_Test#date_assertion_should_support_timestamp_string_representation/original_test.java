@Test public void date_assertion_should_support_timestamp_string_representation(){
  Date date=new Date();
  Timestamp timestamp=new Timestamp(date.getTime());
  String timestampAsString=timestamp.toString();
// --> Flaky here: possible message: 
Expecting:
 <"2019-09-12T02:21:57 (Date@2346f89b)">
to be equal to:
 <"2019-09-12T02:21:57 (Date@2346f8fe)">
but was not.;     assertThat(date).isEqualTo(timestampAsString);
}
