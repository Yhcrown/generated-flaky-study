/** 
 * Verify hostname verifier is set and accepts all
 */
@Test public void verifierAccepts(){
  HttpRequest request=get("https://localhost");
// --> Flaky here: possible message: sun.net.www.protocol.http.HttpURLConnection cannot be cast to javax.net.ssl.HttpsURLConnection;         .getConnection();
  request.trustAllHosts();
  assertNotNull(connection.getHostnameVerifier());
  assertTrue(connection.getHostnameVerifier().verify(null,null));
}
