@Test(expected=WroRuntimeException.class) public void cannotProcessInvalidCss(){
// --> Flaky here: possible message: Unexpected exception, expected<ro.isdc.wro.WroRuntimeException> but was<java.lang.NullPointerException>;     Assert.assertEquals(StringUtils.EMPTY, engine.process("invalidCss"));
}
