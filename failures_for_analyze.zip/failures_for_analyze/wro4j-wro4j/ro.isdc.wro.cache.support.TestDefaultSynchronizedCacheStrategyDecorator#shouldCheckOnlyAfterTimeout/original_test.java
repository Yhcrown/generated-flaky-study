/** 
 * Proves that even if the get() is invoked more times, the check is performed only after a certain period of time.
 */
@Test public void shouldCheckOnlyAfterTimeout() throws Exception {
  final long updatePeriod=10;
  final long delta=5;
  Context.get().getConfig().setResourceWatcherUpdatePeriod(updatePeriod);
  final CacheKey key=new CacheKey("g1",ResourceType.JS,true);
  final long start=System.currentTimeMillis();
  do {
    victim.get(key);
  }
 while (System.currentTimeMillis() - start < updatePeriod - delta);
// --> Flaky here: possible message:  resourceWatcher.check(     ro.isdc.wro.cache.CacheKey@698122b2[   type=JS   groupName=g1   minimize=true   map={} ] ); Wanted 1 time: -> at ro.isdc.wro.cache.support.TestDefaultSynchronizedCacheStrategyDecorator.shouldCheckOnlyAfterTimeout(TestDefaultSynchronizedCacheStrategyDecorator.java:112) But was 50 times. Undesired invocation: -> at ro.isdc.wro.cache.support.DefaultSynchronizedCacheStrategyDecorator.onBeforeGet(DefaultSynchronizedCacheStrategyDecorator.java:136) ;     Mockito.verify(mockResourceWatcher, times(1)).check(key);
}
