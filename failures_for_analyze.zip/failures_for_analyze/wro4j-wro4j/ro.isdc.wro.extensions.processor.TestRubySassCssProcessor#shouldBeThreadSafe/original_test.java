@Test public void shouldBeThreadSafe() throws Exception {
  final Callable<Void> task=new Callable<Void>(){
    @Override public Void call(){
      try {
        processor.process(new StringReader("$side: top;$radius: 10px;.rounded-#{$side} {border-#{$side}-radius: $radius;}"),new StringWriter());
      }
 catch (      final Exception e) {
        throw new RuntimeException(e);
      }
      return null;
    }
  }
;
// --> Flaky here: possible message: java.lang.RuntimeException: ro.isdc.wro.WroRuntimeException: org.jruby.embed.EvalFailedException: java.lang.RuntimeException: com.headius.invokebinder.InvalidTransformException: java.lang.IllegalAccessException: no such method: rubyjit.Sass::Script::Literal$$_perform_168CE349E469F5EE95BDCC7C3B1678073A260AD9693962547.__file__(Sass::Script::Literal$$_perform_168CE349E469F5EE95BDCC7C3B1678073A260AD9693962547,ThreadContext,IRubyObject,IRubyObject,Block)IRubyObject/invokeStatic;     WroTestUtils.runConcurrently(task);
}
