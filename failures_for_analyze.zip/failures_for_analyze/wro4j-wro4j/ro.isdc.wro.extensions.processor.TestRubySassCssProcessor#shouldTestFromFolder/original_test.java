@Test public void shouldTestFromFolder() throws Exception {
  final File testFolder=new File(url.getFile(),"test");
  final File expectedFolder=new File(url.getFile(),"expected");
// --> Flaky here: possible message: org.jruby.embed.EvalFailedException: java.lang.RuntimeException: com.headius.invokebinder.InvalidTransformException: java.lang.IllegalAccessException: no such method: rubyjit.Sass::Script::Literal$$_perform_168CE349E469F5EE95BDCC7C3B1678073A260AD9693962547.__file__(Sass::Script::Literal$$_perform_168CE349E469F5EE95BDCC7C3B1678073A260AD9693962547,ThreadContext,IRubyObject,IRubyObject,Block)IRubyObject/invokeStatic;     WroTestUtils.compareFromDifferentFoldersByName(testFolder, expectedFolder, "css", "css", processor);
}
