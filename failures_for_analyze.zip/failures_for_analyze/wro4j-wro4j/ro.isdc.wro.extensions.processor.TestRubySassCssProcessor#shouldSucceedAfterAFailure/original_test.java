/** 
 * This test proves that Sass Engine behave strangely after the first failure.
 */
@Test public void shouldSucceedAfterAFailure() throws Exception {
  try {
    processor.process(null,new StringReader("$base= #f938ab;"),new StringWriter());
    fail("Should have failed");
  }
 catch (  final Exception e) {
  }
  final String sass=".valid {color: red}  @mixin rounded($side, $radius: 10px) { border-#{$side}-radius: $radius; -moz-border-radius-#{$side}: $radius; -webkit-border-#{$side}-radius: $radius;}#navbar li { @include rounded(top); }";
// --> Flaky here: possible message: org.jruby.embed.EvalFailedException: java.lang.RuntimeException: com.headius.invokebinder.InvalidTransformException: java.lang.IllegalAccessException: no such method: rubyjit.Sass::Script::Literal$$_perform_168CE349E469F5EE95BDCC7C3B1678073A260AD9693962547.__file__(Sass::Script::Literal$$_perform_168CE349E469F5EE95BDCC7C3B1678073A260AD9693962547,ThreadContext,IRubyObject,IRubyObject,Block)IRubyObject/invokeStatic;     processor.process(null, new StringReader(sass), new StringWriter());
}
