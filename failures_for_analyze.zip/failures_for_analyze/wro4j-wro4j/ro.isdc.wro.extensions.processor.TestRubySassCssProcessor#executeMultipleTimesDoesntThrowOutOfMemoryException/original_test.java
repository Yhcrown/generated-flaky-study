@Test public void executeMultipleTimesDoesntThrowOutOfMemoryException(){
  final RubySassEngine engine=new RubySassEngine();
  for (int i=0; i < 100; i++) {
// --> Flaky here: possible message: org.jruby.embed.EvalFailedException: java.lang.RuntimeException: com.headius.invokebinder.InvalidTransformException: java.lang.IllegalAccessException: no such method: rubyjit.Sass::Script::Literal$$_perform_168CE349E469F5EE95BDCC7C3B1678073A260AD9693962547.__file__(Sass::Script::Literal$$_perform_168CE349E469F5EE95BDCC7C3B1678073A260AD9693962547,ThreadContext,IRubyObject,IRubyObject,Block)IRubyObject/invokeStatic;       engine.process("#navbar {width: 80%;}");
  }
}
