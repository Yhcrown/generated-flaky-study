@Test public void canLocateValidResource() throws Exception {
  when(mockRequest.getRequestURL()).thenReturn(new StringBuffer(""));
// --> Flaky here: possible message: www.google.com;     assertNotNull(victim.getInputStream(mockRequest, mockResponse, "http://www.google.com"));
}
