@Test public void testCreateEntityManager(){
  EntityManager entityManager=entityManagerFactory.createEntityManager();
  assertNotNull(entityManager);
// --> Flaky here: possible message: ;     assertTrue(entityManagerFactory.isOpen());    
}
