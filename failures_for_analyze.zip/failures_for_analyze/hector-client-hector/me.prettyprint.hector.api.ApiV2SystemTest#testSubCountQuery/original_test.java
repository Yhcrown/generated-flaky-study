@Test public void testSubCountQuery(){
  String cf="Super1";
  TestCleanupDescriptor cleanup=insertSuperColumns(cf,1,"testSubCountQuery",1,"testSubCountQueryColumn");
  SubCountQuery<String,String,String> cq=createSubCountQuery(ko,se,se,se);
  cq.setRange("c0","c3",100);
// --> Flaky here: possible message: Cassandra encountered an internal error processing this request: TApplicationError type: 6 message:Internal error processing get_count;         setSuperColumn("testSubCountQueryColumn0").execute();
  assertNotNull(r);
  assertEquals(Integer.valueOf(2),r.get());
  deleteColumns(cleanup);
}
