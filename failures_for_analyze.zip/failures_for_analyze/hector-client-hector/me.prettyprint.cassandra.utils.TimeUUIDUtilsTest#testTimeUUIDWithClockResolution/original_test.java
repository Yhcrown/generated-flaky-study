/** 
 * This test must be placed FIRST. Please don't change the order.
 * @throws Exception
 */
@Test public void testTimeUUIDWithClockResolution() throws Exception {
  ClockResolution clock=new MicrosecondsClockResolution();
  long time=clock.createClock();
// --> Flaky here: possible message: expected:<f2b3fc80-b385-1b49-8224-12d08a199e5a> but was:<354325a1-d1f0-11e9-8224-12d08a199e5a>;     assertEquals(TimeUUIDUtils.getTimeUUID(time),
  clock=new MicrosecondsSyncClockResolution();
  java.util.UUID first=TimeUUIDUtils.getTimeUUID(clock);
  java.util.UUID second=TimeUUIDUtils.getTimeUUID(clock);
  assertTrue(second.compareTo(first) > 0);
}
