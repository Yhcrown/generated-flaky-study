@Test public void testInsertGetDelete(){
  simpleCassandraDao.insert("fk1","colName1","value1");
// --> Flaky here: possible message: Cassandra encountered an internal error processing this request: TApplicationError type: 6 message:Internal error processing get;     assertEquals("value1",simpleCassandraDao.get("fk1", "colName1"));
  simpleCassandraDao.delete("colName1","fk1");
  assertNull(simpleCassandraDao.get("fk1","colName1"));
}
