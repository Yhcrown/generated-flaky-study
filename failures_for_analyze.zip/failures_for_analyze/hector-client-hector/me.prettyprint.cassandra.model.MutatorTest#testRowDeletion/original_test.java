@Test public void testRowDeletion(){
  String cf="Standard1";
  long initialTime=keyspace.createClock();
  Mutator<String> m=createMutator(keyspace,se);
  for (int i=0; i < 5; i++) {
    m.addInsertion("key" + i,cf,createColumn("name","value" + i,se,se));
  }
  m.execute();
  m.addDeletion("key0",cf,null,se,(initialTime - 100));
  m.execute();
// --> Flaky here: possible message: Cassandra encountered an internal error processing this request: TApplicationError type: 6 message:Internal error processing get;             setName("name").execute();
  assertEquals("value0",columnResult.get().getValue());
  for (int i=0; i < 5; i++) {
    m.addDeletion("key" + i,cf,null,se);
  }
  m.execute();
// --> Flaky here: possible message: Cassandra encountered an internal error processing this request: TApplicationError type: 6 message:Internal error processing get;             setName("name").execute();
  assertNull(columnResult.get());
}
