@Test public void testMultigetCount(){
  String cf="Standard1";
  Mutator<String> m=createMutator(keyspace,se);
  List<String> keys=new ArrayList<String>();
  for (int i=0; i < 5; i++) {
    String key="k" + i;
    m.addInsertion(key,cf,createColumn("name","value" + i,se,se));
    keys.add(key);
  }
  m.execute();
  MultigetCountQuery<String,String> mcq=new MultigetCountQuery<String,String>(keyspace,se,se);
  mcq.setColumnFamily(cf);
  mcq.setColumnNames("name");
  mcq.setKeys(keys.toArray(new String[]{}));
// --> Flaky here: possible message: Cassandra encountered an internal error processing this request: TApplicationError type: 6 message:Internal error processing multiget_count;     QueryResult<Map<String, Integer>> result = mcq.execute();
  assertEquals(5,result.get().size());
}
