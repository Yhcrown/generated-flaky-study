@Test public void basic() throws Exception {
  loadConfig(ClassicTestConstants.JORAN_INPUT_PREFIX + "unique.xml");
  CachingDateFormatter sdf=new CachingDateFormatter("yyyyMMdd'T'HHmmss");
  String timestamp=sdf.format(System.currentTimeMillis());
  sc.assertIsErrorFree();
  Logger root=lc.getLogger(Logger.ROOT_LOGGER_NAME);
  root.info("hello");
// --> Flaky here: possible message: File target/test-output/TS_20190828T024943log.txt does not exist;     ScaffoldingForRollingTests.existenceCheck(CoreTestConstants.OUTPUT_DIR_PREFIX+"TS_"+timestamp+"log.txt");
}
