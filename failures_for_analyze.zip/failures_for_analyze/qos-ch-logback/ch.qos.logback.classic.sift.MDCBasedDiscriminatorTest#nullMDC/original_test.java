@Test public void nullMDC(){
  event=new LoggingEvent("a",logger,Level.DEBUG,"",null,null);
// --> Flaky here: possible message: expected:<{}> but was:<{compositeProperty=1808205133, max=862149889, linger=session618790256, localProperty=203596822, propertyDefinedWithinSift=1239216831}>;     assertEquals(new HashMap(), event.getMDCPropertyMap());
  String discriminatorValue=discriminator.getDiscriminatingValue(event);
  assertEquals(DEFAULT_VAL,discriminatorValue);
}
