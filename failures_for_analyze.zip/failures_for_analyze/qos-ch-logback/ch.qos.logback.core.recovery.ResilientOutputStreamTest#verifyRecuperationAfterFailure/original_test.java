@Test public void verifyRecuperationAfterFailure() throws Exception {
  File file=new File(CoreTestConstants.OUTPUT_DIR_PREFIX + "resilient" + diff+ ".log");
  ResilientFileOutputStream rfos=new ResilientFileOutputStream(file,true);
  rfos.setContext(context);
  ResilientFileOutputStream spy=spy(rfos);
  spy.write("a".getBytes());
  spy.flush();
  spy.getChannel().close();
  spy.write("b".getBytes());
  spy.flush();
  Thread.sleep(RecoveryCoordinator.BACKOFF_COEFFICIENT_MIN + 10);
  spy.write("c".getBytes());
  spy.flush();
// --> Flaky here: possible message: 
Wanted but not invoked:
resilientFileOutputStream.openNewOutputStream();
-> at ch.qos.logback.core.recovery.ResilientOutputStreamTest.verifyRecuperationAfterFailure(ResilientOutputStreamTest.java:54)

However, there were other interactions with this mock:
-> at ch.qos.logback.core.recovery.ResilientOutputStreamTest.verifyRecuperationAfterFailure(ResilientOutputStreamTest.java:45)
-> at ch.qos.logback.core.recovery.ResilientOutputStreamTest.verifyRecuperationAfterFailure(ResilientOutputStreamTest.java:45)
-> at ch.qos.logback.core.recovery.ResilientOutputStreamTest.verifyRecuperationAfterFailure(ResilientOutputStreamTest.java:46)
-> at ch.qos.logback.core.recovery.ResilientOutputStreamTest.verifyRecuperationAfterFailure(ResilientOutputStreamTest.java:48)
-> at ch.qos.logback.core.recovery.ResilientOutputStreamTest.verifyRecuperationAfterFailure(ResilientOutputStreamTest.java:49)
-> at ch.qos.logback.core.recovery.ResilientOutputStreamTest.verifyRecuperationAfterFailure(ResilientOutputStreamTest.java:49)
-> at ch.qos.logback.core.recovery.ResilientOutputStreamTest.verifyRecuperationAfterFailure(ResilientOutputStreamTest.java:50)
-> at ch.qos.logback.core.recovery.ResilientOutputStreamTest.verifyRecuperationAfterFailure(ResilientOutputStreamTest.java:50)
-> at ch.qos.logback.core.recovery.ResilientOutputStreamTest.verifyRecuperationAfterFailure(ResilientOutputStreamTest.java:50)
-> at ch.qos.logback.core.recovery.ResilientOutputStreamTest.verifyRecuperationAfterFailure(ResilientOutputStreamTest.java:50)
-> at ch.qos.logback.core.recovery.ResilientOutputStreamTest.verifyRecuperationAfterFailure(ResilientOutputStreamTest.java:50)
-> at ch.qos.logback.core.recovery.ResilientOutputStreamTest.verifyRecuperationAfterFailure(ResilientOutputStreamTest.java:52)
-> at ch.qos.logback.core.recovery.ResilientOutputStreamTest.verifyRecuperationAfterFailure(ResilientOutputStreamTest.java:52)
-> at ch.qos.logback.core.recovery.ResilientOutputStreamTest.verifyRecuperationAfterFailure(ResilientOutputStreamTest.java:53)
-> at ch.qos.logback.core.recovery.ResilientOutputStreamTest.verifyRecuperationAfterFailure(ResilientOutputStreamTest.java:53)
-> at ch.qos.logback.core.recovery.ResilientOutputStreamTest.verifyRecuperationAfterFailure(ResilientOutputStreamTest.java:53)
-> at ch.qos.logback.core.recovery.ResilientOutputStreamTest.verifyRecuperationAfterFailure(ResilientOutputStreamTest.java:53)
-> at ch.qos.logback.core.recovery.ResilientOutputStreamTest.verifyRecuperationAfterFailure(ResilientOutputStreamTest.java:53)
;      verify(spy).openNewOutputStream();
}
