@Test public void assertSpringJobBean(){
  assertSimpleElasticJobBean();
  assertThroughputDataflowElasticJobBean();
}
